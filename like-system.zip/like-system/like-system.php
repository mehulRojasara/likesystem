<?php
/*
* Plugin name: MR Like Dislike
* Plugin url: https://google.com
* Author name: MR
* Author url: https://google.com
* Version: 1.0.0
* Description: Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente, odit.
* Licence: GPL2
* Licence url: https://google.com
* Text domain: mrld
*/

// exit if direct aacessed
if(!defined('ABSPATH')){
    exit;
}

// define constant
if(!defined('MRLD_URL')){
    define('MRLD_URL', plugin_dir_url(__FILE__));
}

// enqueue style and scripts
if(!function_exists('mrld_plugin_script')){
    function mrld_plugin_scripts(){
        wp_enqueue_style('mrld-main-style', MRLD_URL . 'assets/css/main.css');
        wp_enqueue_script('mrld-main-js', MRLD_URL . 'assets/js/main.js', array('jQuery'), '1.0.0', true);
    }
    add_action('wp_enqueue_scripts', 'mrld_plugin_scripts');
}

// setting menu and page
require plugin_dir_path(__FILE__) . 'inc/plugin-settings.php';

// setting table
require plugin_dir_path(__FILE__) . 'inc/db.php';

// append buttons to any post

function mrld_like_dislike_buttons($content){
    $like_btn = '<a href="javascript:void(0);" class"mrld-btn btn-like">Like</a>';
    $dislike_btn = '<a href="javascript:void(0);" class"mrld-btn btn-dislike">do not like</a>';
    $button_wrap = '<div class="mrld-like-wrapper">'. $like_btn . $dislike_btn .'</div>';
    
    $content .= $button_wrap;
    // $content .= $dislike_btn;
    return $content;

}
add_filter('the_content', 'mrld_like_dislike_buttons');
