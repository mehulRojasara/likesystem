<?php 
// register menu page
function register_plugin_menu(){
    add_menu_page('MR Like-Dislike', 'Like System Settings', 'manage_options', 'mrld-settings', 'mrld_setting_structure', 'dashicons-thumbs-up',30);
}
add_action('admin_menu', 'register_plugin_menu');

// plugin page html
function mrld_setting_structure(){
    if(!is_admin()){
        return;
    } ?>
    <div class="wrap">
    <h1 style="background-color: #23282d; color: #eee; padding: 10px;"><?= esc_html(get_admin_page_title()); ?></h1>
        <form action="options.php" method="post">
            <?php
                settings_fields('mrld_settings');
                do_settings_sections('mrld_settings');
                submit_button('Save Changes');
            ?>
        </form>
    </div>
    <?php
}

// add plugin settings
function mrld_pluin_setting(){
    // register settings sections
    register_setting('mrld_settings', 'btn_like_label');
    register_setting('mrld_settings', 'btn_dislike_label');

    // add setting section
    add_settings_Section('mrld_label_settings_section', 'Like / Dislike Button Labels','mrld_plugin_setting_section_cb','mrld_settings');

    // add setting fields
    add_settings_field('mrld_like_label_input', 'Like Button Text', 'mrld_like_label_cb', 'mrld_settings', 'mrld_label_settings_section');
    add_settings_field('mrld_dislike_label_input', 'Dislike Button Text', 'mrld_dislike_label_cb', 'mrld_settings', 'mrld_label_settings_section');
}
add_action('admin_init', 'mrld_pluin_setting' );

// callback functions
function mrld_plugin_setting_section_cb(){
    echo "<p>Define Button labels</p>";
}
function mrld_like_label_cb(){
    $likeLabelDB = get_option('btn_like_label'); ?>
    <input type="text" name="btn_like_label" value="<?php echo isset($likeLabelDB) ? esc_attr($likeLabelDB) : ''; ?>" />
    <?php
}
function mrld_dislike_label_cb(){
    $dislikeLabelDB = get_option('btn_dislike_label'); ?>
    <input type="text" name="btn_dislike_label" value="<?php echo isset($dislikeLabelDB) ? esc_attr($dislikeLabelDB) : ''; ?>" />
    <?php
}
?>